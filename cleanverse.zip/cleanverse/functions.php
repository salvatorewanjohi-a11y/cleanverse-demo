<?php
/**
 * Cleanverse Detailing child theme: mobile car detailing, booked like a shop.
 * Services are products priced by vehicle size (the global "Vehicle size" attribute); the cart is the booking,
 * and checkout asks for the car, the date, the time slot and where to come.
 */

const CV_WHATSAPP = '254720721120';
const CV_PHONE    = '0720 721 120';
const CV_IG       = 'https://www.instagram.com/cleanverse_detailing/';
const CV_FONTS    = 'https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap';

// Customer Service Week offer from their Instagram (6 Oct 2026): 5% off all detailing. The code is ours (PLACEHOLDER).
const CV_PROMO_CODE  = 'CSWEEK5';
const CV_PROMO_UNTIL = '2026-10-11';

// Where the vans go, in drop-down order. PLACEHOLDER list built from the brief and the Instagram bio.
const CV_AREAS = [
	'cbd'         => 'Nairobi CBD & Upper Hill',
	'westlands'   => 'Westlands & Parklands',
	'kilimani'    => 'Kilimani, Kileleshwa & Lavington',
	'karen'       => 'Karen & Lang\'ata',
	'runda'       => 'Runda, Gigiri & Muthaiga',
	'kiambu-road' => 'Kiambu Road & Ridgeways',
	'ruaka'       => 'Ruaka & Banana',
	'thika-road'  => 'Thika Road (Kasarani, Roysambu)',
	'ruiru'       => 'Ruiru & Juja',
	'kiambu'      => 'Kiambu Town',
	'south'       => 'South B, South C & Syokimau',
	'other'       => 'Elsewhere in Kenya (travel quoted)',
];
const CV_PLACES = [ 'home' => 'At my home', 'office' => 'At my office / workplace', 'other' => 'Somewhere else (add it to the address)' ];
const CV_SLOTS  = [ '8am' => '8:00 – 10:00 am', '10am' => '10:00 am – 12:00 pm', '12pm' => '12:00 – 2:00 pm', '2pm' => '2:00 – 4:00 pm' ];

// Estimator packages: the services (and second option) each package adds for the chosen vehicle size.
const CV_TIERS = [
	'essential' => [ 'Essential detail', 'Foam bath, hand wash, rims & wax sealant', [ [ 'exterior-foam-bath-wax', null ] ] ],
	'deep'      => [ 'Deep interior & exterior', 'Our full detail, inside and out', [ [ 'full-car-detail', null ] ] ],
	'premium'   => [ 'Premium ceramic package', 'Full detail + 1-year ceramic coating', [ [ 'full-car-detail', null ], [ 'ceramic-coating', '1 year' ] ] ],
];
const CV_ADDONS = [ 'engine-bay-detail', 'headlight-restoration', 'glass-rain-repellent', 'leather-conditioning', 'rim-restoration' ];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'cv-fonts', CV_FONTS, [], null );
	wp_enqueue_style( 'cv', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'cv', $uri . '/assets/cv.js', [], filemtime( $dir . '/assets/cv.js' ), true );
	wp_localize_script( 'cv', 'CV', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'     => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'wa'       => CV_WHATSAPP,
		'est'      => is_front_page() || is_page( 'estimator' ) ? cv_estimator_data() : null,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'cv-fonts', CV_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// Vehicle pages (/vehicle/compact-suv/) need rewrite rules made after the attribute exists.
add_action( 'init', function () {
	if ( get_option( 'cv_rewrites' ) !== '1' && taxonomy_exists( 'pa_vehicle' ) ) {
		flush_rewrite_rules();
		update_option( 'cv_rewrites', '1' );
	}
}, 99 );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function cv_wa_link( $text = '' ) {
	return 'https://wa.me/' . CV_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function cv_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

function cv_promo_on() {
	return current_time( 'Y-m-d' ) <= CV_PROMO_UNTIL;
}

function cv_product( $slug ) {
	$post = get_page_by_path( $slug, OBJECT, 'product' );
	return $post ? wc_get_product( $post->ID ) : null;
}

const CV_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/**
 * "Label: value" lines staff type on the product screen, as label => value pairs.
 */
function cv_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_cv_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function cv_included( $product_id ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_cv_included', true ) ) ) ) );
}

/** Names of the attributes a customer chooses on a variable product, e.g. [ 'Vehicle size', 'Protection' ]. */
function cv_choices( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return [];
	}
	$out = [];
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			$out[] = wc_attribute_label( $attr->get_name(), $product );
		}
	}
	return $out;
}

/** Vehicle-size terms in their set order. */
function cv_vehicle_terms() {
	if ( ! taxonomy_exists( 'pa_vehicle' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'pa_vehicle', 'hide_empty' => false, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

/** The cheapest variation of a product for one vehicle size (and second option, if given). */
function cv_variation_for( WC_Product $product, $size, $second = null ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return null;
	}
	$best = null;
	foreach ( $product->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( ! $v || ! $v->is_purchasable() ) {
			continue;
		}
		$a = $v->get_attributes();
		if ( ( $a['pa_vehicle'] ?? '' ) !== $size || ( $second !== null && ! in_array( $second, $a, true ) ) ) {
			continue;
		}
		if ( ! $best || (float) $v->get_price() < (float) $best->get_price() ) {
			$best = $v;
		}
	}
	return $best;
}

/** Prices and variation ids for the estimator, read from the services so admin price edits show up there too. */
function cv_estimator_data() {
	$sizes = [];
	foreach ( cv_vehicle_terms() as $t ) {
		$sizes[ $t->slug ] = $t->name;
	}
	$tiers = [];
	foreach ( CV_TIERS as $key => [ $name, $sub, $parts ] ) {
		$tier = [ 'name' => $name, 'sub' => $sub, 'parts' => [] ];
		foreach ( $parts as [ $slug, $second ] ) {
			$p = cv_product( $slug );
			if ( ! $p ) {
				continue 2;
			}
			$by = [];
			foreach ( array_keys( $sizes ) as $s ) {
				$v = cv_variation_for( $p, $s, $second );
				if ( $v ) {
					$by[ $s ] = [ 'id' => $v->get_id(), 'price' => (float) $v->get_price() ];
				}
			}
			$tier['parts'][] = [ 'name' => $p->get_name() . ( $second ? ' (' . $second . ')' : '' ), 'by' => $by ];
		}
		$tiers[ $key ] = $tier;
	}
	$addons = [];
	foreach ( CV_ADDONS as $slug ) {
		$p = cv_product( $slug );
		if ( $p && $p->is_purchasable() ) {
			$addons[ $slug ] = [ 'id' => $p->get_id(), 'name' => $p->get_name(), 'price' => (float) $p->get_price() ];
		}
	}
	return [ 'sizes' => $sizes, 'tiers' => $tiers, 'addons' => $addons, 'areas' => CV_AREAS, 'places' => CV_PLACES ];
}

function cv_badges_html( WC_Product $product ) {
	$time = get_post_meta( $product->get_id(), '_cv_time', true );
	$perk = get_post_meta( $product->get_id(), '_cv_perk', true );
	$h    = ( $perk ? '<span class="cv-badge cv-badge--perk">' . esc_html( $perk ) . '</span>' : '' ) . ( $time ? '<span class="cv-badge">' . esc_html( $time ) . '</span>' : '' );
	return $h ? '<div class="cv-badges">' . $h . '</div>' : '';
}

// "From KSh 13,000" instead of a price range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? $html : '<span class="cv-from">From</span> ' . wc_price( $min );
}, 10, 2 );

/** The vehicle-size page being viewed (/vehicle/compact-suv/), if any. */
function cv_current_vehicle() {
	$q = get_queried_object();
	return $q instanceof WP_Term && $q->taxonomy === 'pa_vehicle' ? $q : null;
}

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to my booking' );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return $t;
	}
	$term = cv_current_vehicle();
	if ( $term && $p->is_type( 'variable' ) ) {
		return 'Book for this vehicle';
	}
	$choices = cv_choices( $p );
	return $choices ? 'Choose ' . strtolower( $choices[0] ) : 'Add to booking';
}, 10, 2 );
// On a vehicle-size page, cards open the service with that size already chosen.
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $p ) {
	$term = cv_current_vehicle();
	return $term && $p->is_type( 'variable' ) ? add_query_arg( 'attribute_pa_vehicle', $term->slug, $p->get_permalink() ) : $url;
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', fn( $text, $product ) => $product->is_in_stock() ? 'Taking bookings · Monday to Saturday, Sundays if you book ahead' : 'Fully booked', 10, 2 );

/* -------------------------------------------------------------------------
 * Service page
 * ---------------------------------------------------------------------- */

// Benefit badges, time on site and key facts above the options.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id    = $product->get_id();
	$perks = array_filter( array_map( 'trim', explode( '|', (string) get_post_meta( $id, '_cv_perks', true ) ) ) );
	$time  = get_post_meta( $id, '_cv_time', true );
	echo '<div class="cv-tags">';
	foreach ( $perks as $perk ) {
		echo '<span class="cv-tag">' . esc_html( $perk ) . '</span>';
	}
	echo ( $time ? '<span class="cv-tag cv-tag--time">' . esc_html( $time ) . '</span>' : '' ) . '</div>';
	if ( get_post_meta( $id, '_cv_illustration', true ) === 'yes' ) {
		echo '<p class="cv-note">The picture is an illustration. Ask us on WhatsApp for photos of this work.</p>';
	}
	$keys = array_slice( cv_specs( $id ), 0, 4, true );
	if ( $keys ) {
		echo '<ul class="cv-keyspecs">';
		foreach ( $keys as $k => $v ) {
			echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
		}
		echo '</ul>';
	}
} );

// Book on WhatsApp, the Instagram reel, add-ons and promises under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from ' . cv_money( $product->get_variation_price( 'min' ) ) : cv_money( $product->get_price() );
	$msg   = 'Hi Cleanverse, I\'d like to book: ' . $product->get_name() . ' (' . $price . '). ' . $product->get_permalink();
	echo '<a class="cv-wa-order" data-cv-wa-product="' . esc_attr( $product->get_name() ) . '" data-cv-wa-price="' . esc_attr( $price ) . '" data-cv-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( cv_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . CV_WA_ICON . 'Book or ask on WhatsApp</a>';
	$reel = get_post_meta( $product->get_id(), '_cv_reel', true );
	if ( $reel ) {
		echo '<a class="cv-reel" href="' . esc_url( $reel ) . '" target="_blank" rel="noopener"><span aria-hidden="true">▶</span>Watch us do this job on Instagram</a>';
	}

	$pairs = array_filter( array_map( 'wc_get_product', $product->get_upsell_ids() ) );
	if ( $pairs ) {
		echo '<div class="cv-pairs"><p class="cv-pairs__title">Popular add-ons</p>';
		foreach ( $pairs as $p ) {
			$btn = $p->is_type( 'simple' ) && $p->is_in_stock()
				? '<button type="button" class="cv-pairs__add" data-cv-add="' . $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to your booking">+ Add</button>'
				: '<a class="cv-pairs__add" href="' . esc_url( $p->get_permalink() ) . '">View</a>';
			echo '<div class="cv-pairs__item"><a href="' . esc_url( $p->get_permalink() ) . '">' . $p->get_image( 'woocommerce_gallery_thumbnail', [ 'alt' => '' ] ) . '</a><div><a href="' . esc_url( $p->get_permalink() ) . '">' . esc_html( $p->get_name() ) . '</a><span>' . wp_kses_post( $p->get_price_html() ) . '</span></div>' . $btn . '</div>';
		}
		echo '</div>';
	}

	echo '<div class="cv-promise"><div><span aria-hidden="true">⌖</span><p><strong>We come to you</strong>Home, office or anywhere in Nairobi &amp; Kiambu. Further afield on request.</p></div><div><span aria-hidden="true">⚡</span><p><strong>Our own water &amp; power</strong>The van carries a generator, water and every product we use.</p></div><div><span aria-hidden="true">✓</span><p><strong>Pay after the job</strong>Inspect your car first, then pay by M-Pesa or cash.</p></div></div>';
} );

// What's included, and booking & payment tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$id       = $product->get_id();
	$specs    = cv_specs( $id );
	$included = cv_included( $id );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['title'] = 'About this service';
	}
	if ( $specs || $included ) {
		$tabs['cv_included'] = [
			'title'    => 'What\'s included',
			'priority' => 5,
			'callback' => function () use ( $specs, $included ) {
				echo '<div class="cv-sheet">';
				if ( $included ) {
					echo '<div><h3>What we do</h3><ul class="cv-checks">';
					foreach ( $included as $s ) {
						echo '<li>' . esc_html( $s ) . '</li>';
					}
					echo '</ul></div>';
				}
				echo '<div><h3>Good to know</h3><table class="cv-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table></div></div>';
			},
		];
	}
	$tabs['cv_booking'] = [
		'title'    => 'Booking & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Book online:</strong> add the service, then choose your date, time slot and where we should come at checkout. We call to confirm.</li><li><strong>Where:</strong> at your home or office across Nairobi &amp; Kiambu. Elsewhere in Kenya on request (travel quoted).</li><li><strong>When:</strong> Monday to Saturday; Sundays too if you book ahead.</li><li><strong>Pay:</strong> by M-Pesa or cash after the job, once you\'ve inspected your car.</li><li><strong>WhatsApp:</strong> prefer to chat? Tap the WhatsApp button and book in the chat on ' . esc_html( CV_PHONE ) . '.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Service cards
 * ---------------------------------------------------------------------- */

function cv_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo) and the details pop-up on card images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = cv_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt     = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'cv-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$extra = sprintf( '<button type="button" class="cv-qv-btn" data-cv-qv="%1$d" aria-label="Details of %2$s">View details</button>', $product->get_id(), esc_attr( $product->get_name() ) );
	$pos   = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Category label above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = cv_card_product( $instance );
	$badge   = $product ? get_post_meta( $product->get_id(), '_cv_badge', true ) : '';
	return ( $badge ? '<p class="cv-card-badge">' . esc_html( $badge ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Benefit and time badges, and on a vehicle-size page the price for that size.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = cv_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$term = cv_current_vehicle();
	if ( $term && $product->is_type( 'variable' ) ) {
		$v = cv_variation_for( $product, $term->slug );
		if ( $v ) {
			$content = '<div class="wp-block-woocommerce-product-price"><div class="wc-block-components-product-price">' . ( count( cv_choices( $product ) ) > 1 ? '<span class="cv-from">From</span> ' : '' ) . wc_price( $v->get_price() ) . '</div></div>';
		}
	}
	return cv_badges_html( $product ) . $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and service lists
 * ---------------------------------------------------------------------- */

function cv_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// Service pillars: one tile per category, with the photo of its first service.
add_shortcode( 'cv_services', function () {
	$h   = '<div class="cv-services">';
	$sub = [
		'full-detailing'    => 'Foam bath · Interior deep clean · Leather care',
		'ceramic-paint'     => 'Swirl & scratch removal · 1–5 year ceramic',
		'ppf-tint'          => 'Paint protection film · Heat & UV tint',
		'maintenance-plans' => 'Twice or four times a month, at your door',
		'add-ons'           => 'Engine bay · Headlights · Glass · Rims',
		'home-cleaning'     => 'Sofas & carpets, cleaned at home',
	];
	foreach ( cv_categories() as $t ) {
		$list = wc_get_products( [ 'category' => [ $t->slug ], 'limit' => 1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
		$img  = $list ? $list[0]->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h   .= sprintf(
			'<a class="cv-service" href="%s"><span class="cv-service__img">%s</span><span class="cv-service__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			$img,
			esc_html( $t->name ),
			esc_html( $sub[ $t->slug ] ?? '' )
		);
	}
	return $h . '</div>';
} );

// "Book by vehicle type": a tile per size with its full-detail price, plus company fleets.
add_shortcode( 'cv_vehicles', function () {
	$full  = cv_product( 'full-car-detail' );
	$icons = [
		'sedan'       => 'M6 42h88M12 42v-6c0-3 2-4 5-5l9-9c2-2 4-3 7-3h26c3 0 5 1 7 3l9 8 11 2c3 1 4 3 4 6v4',
		'compact-suv' => 'M6 42h88M10 42V30c0-3 2-5 5-5l9-9h36c3 0 5 1 7 3l8 7h8c3 0 5 2 5 5v11',
		'midsize-suv' => 'M6 42h88M9 42V26c0-3 2-5 5-5l6-8h48c3 0 5 1 7 3l7 6h5c3 0 5 2 5 5v15',
		'suv-pickup'  => 'M6 42h88M9 42V22c0-2 2-4 4-4h34l9 10h30c3 0 5 2 5 5v9M47 18v24',
	];
	$examples = [ 'sedan' => 'Axio, Mazda 3, C-Class, SLK', 'compact-suv' => 'RAV4, X-Trail, CX-5', 'midsize-suv' => 'Harrier, Discovery Sport, GLC', 'suv-pickup' => 'Prado, Defender, Hilux, Silverado' ];
	$h = '<div class="cv-vehicles">';
	foreach ( cv_vehicle_terms() as $t ) {
		$v  = $full ? cv_variation_for( $full, $t->slug ) : null;
		$h .= sprintf(
			'<a class="cv-vehicle" href="%s"><svg viewBox="0 0 100 52" aria-hidden="true"><path d="%s"/><circle cx="28" cy="42" r="7"/><circle cx="72" cy="42" r="7"/></svg><strong>%s</strong><em>%s</em>%s</a>',
			esc_url( get_term_link( $t ) ),
			esc_attr( $icons[ $t->slug ] ?? $icons['sedan'] ),
			esc_html( $t->name ),
			esc_html( $examples[ $t->slug ] ?? '' ),
			$v ? '<span>Full detail <b>' . esc_html( cv_money( $v->get_price() ) ) . '</b></span>' : ''
		);
	}
	$h .= '<a class="cv-vehicle cv-vehicle--fleet" href="/fleet-commercial/"><svg viewBox="0 0 100 52" aria-hidden="true"><path d="M6 42h88M8 42V14c0-2 2-4 4-4h48v32M60 20h18l12 12v10"/><circle cx="24" cy="42" r="7"/><circle cx="76" cy="42" r="7"/></svg><strong>Company fleets</strong><em>Vans, pool cars &amp; executive fleets</em><span>Get a fleet quote →</span></a>';
	return $h . '</div>';
} );

// Category and vehicle-size chips above shop, category, vehicle and search pages.
function cv_chip( $label, $url, $on, $count = null, $small = false ) {
	return sprintf( '<a class="cv-chip%s%s" href="%s">%s%s</a>', $small ? ' cv-chip--sm' : '', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}
add_shortcode( 'cv_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="cv-filters" aria-label="Filter services"><div class="cv-filters__row">';
	$h .= cv_chip( 'All services', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( cv_categories() as $t ) {
		$h .= cv_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="cv-filters__row"><span>Prices for</span>';
	foreach ( cv_vehicle_terms() as $t ) {
		$h .= cv_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, null, true );
	}
	return $h . '</div></nav>';
} );

// Real client feedback from the "Client Reviews" highlight on their Instagram (WhatsApp screenshots).
// They have no Google listing yet, so there is no star rating to show.
add_shortcode( 'cv_reviews', function () {
	$reviews = [
		[ 'Impressed with the detailing! Attention to detail, quality work, and friendly service. The car looks and feels brand new. Five stars.', 'Full detail client' ],
		[ 'Hi, I really love the results. My car is so clean, thank you.', 'Doorstep detail client' ],
		[ 'The detailer has finished the job and he has done a very good job.', 'Doorstep detail client' ],
	];
	$h = '<div class="cv-reviews"><a class="cv-reviews__score" href="' . esc_url( CV_IG ) . '" target="_blank" rel="noopener"><strong>2,000+</strong><span>people follow our jobs on Instagram</span><em>See the Client Reviews highlight →</em></a><div class="cv-reviews__list">';
	foreach ( $reviews as [ $text, $who ] ) {
		$h .= '<figure class="cv-review"><span class="cv-quote" aria-hidden="true">“</span><blockquote>' . esc_html( $text ) . '</blockquote><figcaption><strong>' . esc_html( $who ) . '</strong><span>Sent to us on WhatsApp</span></figcaption></figure>';
	}
	return $h . '</div></div>';
} );

// Before / after slider: the same Defender in the foam bath and finished (stills from their own reel).
add_shortcode( 'cv_before_after', function () {
	$dir = get_stylesheet_directory_uri() . '/assets/photos/';
	return '<figure class="cv-ba" data-cv-ba style="--pos:50%"><img src="' . esc_url( $dir . 'after.webp' ) . '" alt="Overfinch Land Rover Defender after a Cleanverse full detail" width="720" height="720" loading="lazy"><div class="cv-ba__before"><img src="' . esc_url( $dir . 'before.webp' ) . '" alt="The same Defender during the foam bath" width="720" height="720" loading="lazy"></div><span class="cv-ba__label cv-ba__label--l">Foam bath</span><span class="cv-ba__label cv-ba__label--r">Finished</span><span class="cv-ba__handle" aria-hidden="true"></span><input type="range" min="0" max="100" value="50" aria-label="Slide to compare the foam bath with the finished car"></figure>';
} );

// Package customizer: vehicle size × package × add-ons × where. cv.js does the maths, the booking and WhatsApp.
add_shortcode( 'cv_estimator', function () {
	$est = cv_estimator_data();
	if ( ! $est['tiers'] || ! $est['sizes'] ) {
		return '';
	}
	$opt = fn( $v, $label ) => '<option value="' . esc_attr( $v ) . '">' . esc_html( $label ) . '</option>';
	ob_start();
	?>
	<form class="cv-est" data-cv-estimator novalidate>
		<ol class="cv-est__steps" aria-hidden="true"><li class="is-on">Vehicle</li><li>Package</li><li>Add-ons</li><li>Where</li></ol>

		<fieldset class="cv-est__step" data-step="1">
			<legend><span>1</span> Your vehicle</legend>
			<div class="cv-est__cards cv-est__cards--4">
				<?php $i = 0; foreach ( $est['sizes'] as $slug => $name ) : ?>
					<label><input type="radio" name="size" value="<?php echo esc_attr( $slug ); ?>"<?php echo $i++ ? '' : ' checked'; ?>><strong><?php echo esc_html( $name ); ?></strong></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="cv-est__step" data-step="2">
			<legend><span>2</span> Package</legend>
			<div class="cv-est__cards">
				<?php foreach ( $est['tiers'] as $key => $t ) : ?>
					<label><input type="radio" name="tier" value="<?php echo esc_attr( $key ); ?>"<?php echo $key === 'deep' ? ' checked' : ''; ?>><strong><?php echo esc_html( $t['name'] ); ?></strong><em><?php echo esc_html( $t['sub'] ); ?></em><b data-cv-tier-price="<?php echo esc_attr( $key ); ?>"></b></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="cv-est__step" data-step="3">
			<legend><span>3</span> Add-ons</legend>
			<div class="cv-est__addons">
				<?php foreach ( $est['addons'] as $slug => $a ) : ?>
					<label><input type="checkbox" name="addon" value="<?php echo esc_attr( $slug ); ?>"><span><?php echo esc_html( $a['name'] ); ?></span><b>+ <?php echo esc_html( cv_money( $a['price'] ) ); ?></b></label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="cv-est__step" data-step="4">
			<legend><span>4</span> Where should we come?</legend>
			<div class="cv-est__grid">
				<label>Place<select name="place"><?php foreach ( CV_PLACES as $k => $v ) echo $opt( $k, $v ); ?></select></label>
				<label>Area<select name="area"><?php foreach ( CV_AREAS as $k => $v ) echo $opt( $k, $v ); ?></select></label>
			</div>
		</fieldset>

		<div class="cv-est__result" aria-live="polite">
			<div>
				<p class="cv-est__label">Your price</p>
				<p class="cv-est__total" data-cv-est-total>KSh 0</p>
				<p class="cv-est__summary" data-cv-est-summary></p>
				<p class="cv-small" data-cv-est-note></p>
			</div>
			<div class="cv-est__actions">
				<button type="button" class="wp-element-button" data-cv-est-book>Book this package</button>
				<a class="cv-wa-order cv-est__wa" data-cv-est-wa href="<?php echo esc_url( cv_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo CV_WA_ICON; ?>Get this quote on WhatsApp</a>
			</div>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Fleet & commercial request: composes a WhatsApp message (nothing is stored on the site).
add_shortcode( 'cv_fleet_form', function () {
	$sel = fn( $name, array $opts ) => '<select name="' . $name . '">' . implode( '', array_map( fn( $o ) => '<option>' . esc_html( $o ) . '</option>', $opts ) ) . '</select>';
	ob_start();
	?>
	<form class="cv-est cv-fleet" data-cv-fleet>
		<div class="cv-est__grid">
			<label>Company / organisation<input type="text" name="company" autocomplete="organization" required></label>
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
			<label>Number of vehicles<input type="number" name="count" min="2" max="500" value="5" inputmode="numeric"></label>
			<label>Mostly<?php echo $sel( 'types', [ 'Saloons & pool cars', 'SUVs & executive cars', 'Vans & pickups', 'A mix' ] ); ?></label>
			<label>How often<?php echo $sel( 'often', [ 'Once (a one-off clean-up)', 'Every week', 'Twice a month', 'Every month' ] ); ?></label>
			<label>Where are the vehicles?<?php echo $sel( 'area', array_values( CV_AREAS ) ); ?></label>
			<label>Service<?php echo $sel( 'service', [ 'Full detail', 'Exterior foam bath & wax', 'Interior deep clean', 'Not sure: advise us' ] ); ?></label>
		</div>
		<label class="cv-fleet__notes">Anything else (parking, working hours, branded vehicles)<textarea name="notes" rows="3"></textarea></label>
		<div class="cv-est__result">
			<p class="cv-small">We reply on WhatsApp with a per-vehicle fleet price and a schedule that keeps your vehicles on the road.</p>
			<button type="submit" class="cv-wa-order cv-est__wa"><?php echo CV_WA_ICON; ?>Send fleet request on WhatsApp</button>
		</div>
	</form>
	<?php
	return ob_get_clean();
} );

// Details pop-up (filled in by cv.js) and the floating WhatsApp button.
add_action( 'wp_footer', function () {
	echo '<dialog id="cv-qv" class="cv-dialog cv-qv" aria-label="Service details"><form method="dialog"><button class="cv-dialog__close" aria-label="Close">×</button></form><div data-cv-qv-body></div></dialog>';
	echo '<a class="cv-wa-float" href="' . esc_url( cv_wa_link( 'Hi Cleanverse, I\'d like a quote for my car:' ) ) . '" target="_blank" rel="noopener" aria-label="Chat with Cleanverse on WhatsApp">' . CV_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart (the booking), checkout, confirmation
 * ---------------------------------------------------------------------- */

function cv_cart_note_html() {
	return '<div class="cv-cart-note"><strong>Next:</strong> choose a date, a time slot and where we should come. Nothing is paid online: you pay after the job.</div>';
}
function cv_wa_cart_html() {
	return '<button type="button" class="cv-wa-cart" data-cv-wa-cart>' . CV_WA_ICON . 'Send this booking to WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => cv_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . cv_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', cv_cart_note_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="cv-wa-cart-wrap">' . cv_wa_cart_html() . '</div>' );

// Booking words on the cart and checkout buttons.
add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Confirm my booking' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Choose date, time & place' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your booking' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Book now' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View booking' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	// Checkout steps in booking words.
	$steps = [
		'woocommerce/checkout-contact-information-block'  => [ 'Your contact details', 'We send your booking confirmation here.' ],
		'woocommerce/checkout-billing-address-block'      => [ 'Where should the van come?', 'Your name and the address where your car will be.' ],
		'woocommerce/checkout-additional-information-block' => [ 'Your car & appointment', 'Pick a date and a time slot. We call to confirm.' ],
		'woocommerce/checkout-payment-block'              => [ 'How you\'ll pay', 'Nothing is paid online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	// The car and the appointment come before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

// Add-ons are shown as "Popular add-ons" next to the button, so skip WooCommerce's own upsell row.
add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

// Vehicle-size pages: a readable breadcrumb instead of "Product Vehicle size".
add_filter( 'woocommerce_get_breadcrumb', function ( $crumbs ) {
	if ( cv_current_vehicle() ) {
		foreach ( $crumbs as $i => $c ) {
			if ( str_contains( (string) $c[0], 'Vehicle size' ) ) {
				$crumbs[ $i ] = [ 'Prices by vehicle', home_url( '/#vehicles' ) ];
			}
		}
	}
	return $crumbs;
} );

/** The next three weeks as booking dates: Y-m-d => "Thu 8 Oct". */
function cv_booking_dates() {
	$out = [];
	$day = new DateTime( 'tomorrow', wp_timezone() );
	for ( $i = 0; $i < 21; $i++ ) {
		$out[ $day->format( 'Y-m-d' ) ] = $day->format( 'D j M' ) . ( $day->format( 'N' ) === '7' ? ' (Sunday: book ahead)' : '' );
		$day->modify( '+1 day' );
	}
	return $out;
}

// What the detailers need to know: field => [ label, short label, options (null = text), required ].
function cv_checkout_fields() {
	return [
		'cv/vehicle' => [ 'Vehicle make & model (e.g. Toyota Prado)', 'Vehicle', null, true ],
		'cv/plate'   => [ 'Number plate & colour', 'Plate & colour', null, false ],
		'cv/date'    => [ 'Preferred date', 'Date', cv_booking_dates(), true ],
		'cv/time'    => [ 'Time slot (when we arrive)', 'Time', CV_SLOTS, true ],
		'cv/place'   => [ 'Where should we come?', 'Place', CV_PLACES, true ],
		'cv/area'    => [ 'Area', 'Area', CV_AREAS, true ],
	];
}
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	foreach ( cv_checkout_fields() as $id => [ $label, , $options, $required ] ) {
		$field = [ 'id' => $id, 'label' => $label, 'location' => 'order', 'type' => $options ? 'select' : 'text', 'required' => $required ];
		if ( $options ) {
			$field['options'] = array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( $options ), $options );
		}
		woocommerce_register_additional_checkout_field( $field );
	}
} );

function cv_booking_code( WC_Order $order ) {
	return 'CV-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
/** Booking details from the checkout fields, as short label => readable value. */
function cv_booking_details( WC_Order $order ) {
	$out = [];
	foreach ( cv_checkout_fields() as $key => [ , $label, $options ] ) {
		$value = (string) $order->get_meta( '_wc_other/' . $key );
		if ( $value !== '' ) {
			$out[ $label ] = $options[ $value ] ?? $value;
		}
	}
	return $out;
}
function cv_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Cleanverse, I just booked online (' . cv_booking_code( $order ) . '):' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . html_entity_decode( $item->get_name(), ENT_QUOTES ) . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . cv_money( $item->get_total() );
	}
	$lines[] = 'Total: ' . cv_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	foreach ( cv_booking_details( $order ) as $label => $value ) {
		$lines[] = $label . ': ' . $value;
	}
	$address = trim( implode( ', ', array_filter( [ $order->get_billing_address_1(), $order->get_billing_address_2(), $order->get_billing_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Address: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return cv_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	$d    = cv_booking_details( $order );
	$when = implode( ' · ', array_filter( [ $d['Date'] ?? '', $d['Time'] ?? '', $d['Area'] ?? '' ] ) );
	return $content . '<div class="cv-thanks"><p class="cv-thanks__code">Booking number <strong>' . esc_html( cv_booking_code( $order ) ) . '</strong></p>' . ( $when ? '<p class="cv-thanks__when">' . esc_html( $when ) . '</p>' : '' ) . '<ol><li>We call you shortly to confirm your slot.</li><li>The van arrives with its own water, power and products.</li><li>You inspect your car, then pay by M-Pesa or cash.</li></ol><a class="wp-element-button cv-wa-btn" href="' . esc_attr( cv_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . CV_WA_ICON . 'Send my booking to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Booking number:</strong> ' . esc_html( cv_booking_code( $order ) ) . '</p>';
} );

// Staff edit the card badges, the facts, what's included and the Instagram reel on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_cv_badge', 'label' => 'Card label', 'description' => 'Small label above the name, e.g. "Most booked".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_cv_perk', 'label' => 'Card badge', 'description' => 'One benefit shown on the card, e.g. "9H ceramic layer".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_cv_perks', 'label' => 'Benefit badges', 'description' => 'Shown on the service page, separated by |, e.g. "Hydrophobic finish | 9H ceramic layer".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_cv_time', 'label' => 'Time on site', 'description' => 'e.g. "4–6 hours on site".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_cv_reel', 'label' => 'Instagram reel link', 'description' => 'A video of this job, shown as "Watch us do this job".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_cv_specs', 'label' => 'Good to know', 'rows' => 5, 'description' => 'One per line, as "Label: value". The first four also show next to the price.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_cv_included', 'label' => 'What\'s included', 'rows' => 8, 'description' => 'One item per line.' ] );
	echo '<p class="form-field"><em>Prices by vehicle: the "Vehicle size" attribute makes the variations; set each variation\'s price under Variations. "Popular add-ons" = Linked Products → Upsells.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_cv_badge', '_cv_perk', '_cv_perks', '_cv_time' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
	if ( isset( $_POST['_cv_reel'] ) ) { // phpcs:ignore
		$product->update_meta_data( '_cv_reel', esc_url_raw( wp_unslash( $_POST['_cv_reel'] ) ) ); // phpcs:ignore
	}
	foreach ( [ '_cv_specs', '_cv_included' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore
			$product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode or county; the address is where the van parks.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode']  = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['state']     = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_1'] = [ 'label' => 'Street, estate or building (where we park)' ];
	$locale['KE']['address_2'] = [ 'label' => 'House / office number, gate or landmark' ];
	$locale['KE']['city']      = [ 'label' => 'Town (e.g. Nairobi, Kiambu, Ruiru)' ];
	$locale['KE']['phone']     = [ 'required' => true ];
	return $locale;
} );

// Booking words for WooCommerce's shop words.
add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) {
		return $text;
	}
	return [
		'Related products'  => 'You may also like',
		'Continue shopping' => 'Keep browsing services',
		'Order received'    => 'Booking received',
		'Thank you. Your order has been received.' => 'Thank you. Your booking has been received.',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', function ( $text, $single, $plural, $number, $domain ) {
	return $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your booking.' : $text;
}, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#121212\">\n";
} );

// Shortcode blocks: run the shortcode as is. The block's automatic paragraphs break the
// estimator's and reviews' grids with stray <p> and <br> tags.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	return ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre;
}, 10, 2 );

// The announcement bar carries the Customer Service Week offer until it ends.
add_filter( 'render_block_core/paragraph', function ( $content ) {
	if ( ! str_contains( $content, 'data-cv-promo' ) ) {
		return $content;
	}
	return cv_promo_on() ? $content : preg_replace( '#<span data-cv-promo>.*?</span><span class="cv-dot">\|</span>#s', '', $content );
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
