( function () {
	const cfg = window.CV || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	const store = {
		get: ( k ) => {
			try {
				return JSON.parse( sessionStorage.getItem( k ) || 'null' );
			} catch ( e ) {
				return null;
			}
		},
		set: ( k, v ) => {
			try {
				sessionStorage.setItem( k, JSON.stringify( v ) );
			} catch ( e ) {}
		},
	};

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.cv-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'cv-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'cv-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	const addedMsg = () => '✓ Added to your booking · <a href="' + esc( cfg.checkout || '/checkout/' ) + '">Choose date &amp; time</a>';
	document.body.addEventListener( 'wc-blocks_added_to_cart', ( e ) => {
		if ( ! ( e.detail && e.detail.cvQuiet ) ) toast( addedMsg() );
	} );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( addedMsg() ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store: iStore } = await import( '@wordpress/interactivity' );
			const wc = iStore( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function addItem( id ) {
		if ( ! nonce ) await getCart();
		const res = await fetch( cfg.store + 'cart/add-item', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', Nonce: nonce },
			body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
		} );
		const cart = await res.json();
		if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
		return cart;
	}
	// ids: products or chosen variations. Opens the booking drawer once everything is in.
	async function addToCart( ids, btn, quiet ) {
		if ( btn ) btn.disabled = true;
		try {
			let cart;
			for ( const id of [].concat( ids ) ) cart = await addItem( id );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true, detail: { cvQuiet: !! quiet } } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
			return true;
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your booking. Please try again.' ) );
			return false;
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-cv-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.cvAdd, b );
	} );

	/* WhatsApp booking from the cart ------------------------------------- */
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		return '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' × ' + it.quantity : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-cv-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your booking is empty.' );
				return;
			}
			const where = store.get( 'cv-where' );
			const lines = [ 'Hi Cleanverse, I\'d like to book:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Total: ' + fmt( money( cart.totals.total_price, cart.totals ) ) );
			if ( where ) lines.push( 'Where: ' + where.place + ', ' + where.area );
			lines.push( 'Vehicle (make & model): ', 'Preferred date & time: ' );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your booking. Please try again.' );
		}
	} );

	/* Service page: option buttons ------------------------------------- */
	// Turns WooCommerce's option drop-downs into buttons (the drop-downs stay in the form, hidden, so
	// WooCommerce still swaps the price). Vehicle sizes show their price.
	function variationPrices( form ) {
		try {
			return JSON.parse( form.dataset.product_variations || '[]' );
		} catch ( e ) {
			return [];
		}
	}
	function initOptions() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.cvSw ) return;
			sel.dataset.cvSw = '1';
			const form = sel.closest( 'form' );
			const wrap = document.createElement( 'div' );
			wrap.setAttribute( 'role', 'radiogroup' );
			wrap.className = 'cv-sw';
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			wrap.innerHTML = opts.map( ( o ) => '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '"><span>' + esc( o.text ) + '</span></button>' ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'cv-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( form );
			} );
			// Vehicle-size buttons show the price for that size (the lowest, if there's a second choice).
			if ( sel.name === 'attribute_pa_vehicle' ) {
				const vars = variationPrices( form );
				$$( 'button', wrap ).forEach( ( b ) => {
					const prices = vars.filter( ( v ) => v.attributes && v.attributes.attribute_pa_vehicle === b.dataset.v ).map( ( v ) => v.display_price );
					if ( prices.length ) b.insertAdjacentHTML( 'beforeend', '<small>' + ( prices.length > 1 ? 'from ' : '' ) + esc( fmt( Math.min( ...prices ) ) ) + '</small>' );
				} );
			}
			paint();
			updateWaProduct( form );
		} );
		// Hide WooCommerce's "Clear" link: an option is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The service page's WhatsApp button names the options the customer picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-cv-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => ( s.value ? s.options[ s.selectedIndex ].text : '' ) ).filter( Boolean ).join( ', ' );
		const msg = 'Hi Cleanverse, I\'d like to book: ' + a.dataset.cvWaProduct + ( picked ? ' (' + picked + ')' : ' (' + a.dataset.cvWaPrice + ')' ) + '. ' + a.dataset.cvWaUrl;
		a.href = waUrl( msg );
	}

	/* Details pop-up ----------------------------------------------------- */
	const choiceNames = ( p ) => ( p.attributes || [] ).filter( ( a ) => a.has_variations ).map( ( a ) => plain( a.name ).toLowerCase() );
	const QV_MAX = 8;
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-cv-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'cv-qv' );
		const body = dlg && dlg.querySelector( '[data-cv-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="cv-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.cvQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="cv-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-cv-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const cats = p.categories && p.categories[ 0 ] ? plain( p.categories[ 0 ].name ) : '';
			const termName = ( attrName, val ) => {
				const attr = ( p.attributes || [] ).find( ( a ) => a.name === attrName || a.taxonomy === attrName );
				const term = attr && ( attr.terms || [] ).find( ( t ) => t.slug === val || t.name === val );
				return term ? plain( term.name ) : val;
			};
			let choose = '';
			let buy;
			if ( ! p.is_purchasable || ! p.is_in_stock ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View service</a>';
			} else if ( p.variations && p.variations.length && p.variations.length <= QV_MAX ) {
				choose = '<p class="cv-qv__label">' + esc( choiceNames( p ).join( ' & ' ) ) + ': <strong data-cv-qv-picked></strong></p><div class="cv-sw">' + p.variations.map( ( v, i ) => {
					const label = ( v.attributes || [] ).map( ( a ) => termName( a.name, a.value ) ).join( ' · ' );
					return '<button type="button" data-cv-qv-var="' + v.id + '" data-label="' + esc( label ) + '"' + ( i ? '' : ' class="is-on"' ) + '><span>' + esc( label ) + '</span></button>';
				} ).join( '' ) + '</div>';
				buy = '<button type="button" class="wp-element-button" data-cv-add="' + p.variations[ 0 ].id + '" data-cv-qv-buy>Add to my booking</button>';
			} else if ( p.type === 'variable' ) {
				buy = '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose ' + esc( choiceNames( p )[ 0 ] || 'options' ) + '</a>';
			} else {
				buy = '<button type="button" class="wp-element-button" data-cv-add="' + p.id + '">Add to my booking</button>';
			}
			body.innerHTML = '<div class="cv-qv__grid"><div class="cv-qv__media"><div class="cv-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="cv-qv__info">' + ( cats ? '<p class="cv-eyebrow">' + esc( cats ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="cv-qv__price">' + p.price_html + '</div>' +
				'<div class="cv-qv__desc">' + ( p.short_description || '' ) + '</div>' + choose +
				'<div class="cv-qv__actions">' + buy + '<a class="cv-link" href="' + esc( p.permalink ) + '">What\'s included →</a></div></div></div>';
			const first = body.querySelector( '[data-cv-qv-var]' );
			if ( first ) pickQvVariation( first );
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this service. Please try again.</p>';
		}
	} );
	// Variation price: the Store API lists variations without it, so fetch the chosen one.
	async function pickQvVariation( btn ) {
		const box = btn.closest( '[data-cv-qv-body]' );
		$$( '[data-cv-qv-var]', box ).forEach( ( b ) => b.classList.toggle( 'is-on', b === btn ) );
		const picked = box.querySelector( '[data-cv-qv-picked]' );
		if ( picked ) picked.textContent = btn.dataset.label;
		const buy = box.querySelector( '[data-cv-qv-buy]' );
		if ( buy ) buy.dataset.cvAdd = btn.dataset.cvQvVar;
		try {
			const v = await ( await fetch( cfg.store + 'products/' + btn.dataset.cvQvVar ) ).json();
			// A slower reply for an earlier pick must not overwrite the current one.
			if ( ! btn.classList.contains( 'is-on' ) ) return;
			const price = box.querySelector( '.cv-qv__price' );
			if ( price && v.price_html ) price.innerHTML = v.price_html;
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-cv-qv-var]' );
		if ( b ) pickQvVariation( b );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-cv-qv-img]' );
		if ( ! t ) return;
		const main = t.closest( '.cv-qv__media' ).querySelectorAll( '.cv-qv__main img' );
		main.forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.cvQvImg ) ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.cv-dialog' ) ) e.target.close();
		// Close the call / WhatsApp menu when clicking elsewhere.
		$$( 'details.cv-contact[open]' ).forEach( ( d ) => {
			if ( ! d.contains( e.target ) ) d.open = false;
		} );
	} );

	/* Package customizer ------------------------------------------------- */
	function estimate( form ) {
		const est = cfg.est;
		const f = new FormData( form );
		const size = f.get( 'size' );
		const tier = est.tiers[ f.get( 'tier' ) ];
		const items = [];
		let total = 0;
		tier.parts.forEach( ( part ) => {
			const hit = part.by[ size ];
			if ( hit ) {
				items.push( { id: hit.id, name: part.name, price: hit.price } );
				total += hit.price;
			}
		} );
		f.getAll( 'addon' ).forEach( ( slug ) => {
			const a = est.addons[ slug ];
			if ( a ) {
				items.push( { id: a.id, name: a.name, price: a.price } );
				total += a.price;
			}
		} );
		return { size, sizeName: est.sizes[ size ], tierName: tier.name, items, total, placeKey: f.get( 'place' ), place: est.places[ f.get( 'place' ) ], area: est.areas[ f.get( 'area' ) ], far: f.get( 'area' ) === 'other' };
	}
	function initEstimator() {
		if ( ! cfg.est ) return;
		$$( '[data-cv-estimator]' ).forEach( ( form ) => {
			const out = form.querySelector( '[data-cv-est-total]' );
			const sum = form.querySelector( '[data-cv-est-summary]' );
			const note = form.querySelector( '[data-cv-est-note]' );
			const wa = form.querySelector( '[data-cv-est-wa]' );
			const book = form.querySelector( '[data-cv-est-book]' );
			const steps = $$( '.cv-est__steps li', form );
			const update = () => {
				$$( '.cv-est__cards label, .cv-est__addons label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				const r = estimate( form );
				// Each package card shows its price for the chosen vehicle.
				$$( '[data-cv-tier-price]', form ).forEach( ( el ) => {
					const t = cfg.est.tiers[ el.dataset.cvTierPrice ];
					el.textContent = fmt( t.parts.reduce( ( s, p ) => s + ( p.by[ r.size ] ? p.by[ r.size ].price : 0 ), 0 ) );
				} );
				out.textContent = fmt( r.total );
				sum.textContent = r.sizeName + ' · ' + r.items.map( ( i ) => i.name ).join( ' + ' );
				note.textContent = r.far
					? 'Outside Nairobi & Kiambu: we add travel, quoted before we confirm. Pay after the job.'
					: 'We come to ' + ( { home: 'your home', office: 'your office' }[ r.placeKey ] || 'you' ) + ' in ' + r.area + ': no call-out fee. Pay after the job.';
				wa.href = waUrl( [ 'Hi Cleanverse, I\'d like to book a detail:', '• Vehicle: ' + r.sizeName, ...r.items.map( ( i ) => '• ' + i.name + ' – ' + fmt( i.price ) ), 'Website price: ' + fmt( r.total ), 'Where: ' + r.place + ', ' + r.area, 'Make & model: ', 'Preferred date & time: ' ].join( '\n' ) );
				store.set( 'cv-where', { place: r.place, area: r.area, placeKey: new FormData( form ).get( 'place' ), areaKey: new FormData( form ).get( 'area' ) } );
			};
			form.addEventListener( 'input', update );
			form.addEventListener( 'change', update );
			form.addEventListener( 'submit', ( e ) => e.preventDefault() );
			book.addEventListener( 'click', async () => {
				const r = estimate( form );
				if ( ! r.items.length ) return;
				const label = book.textContent;
				book.textContent = 'Adding…';
				const ok = await addToCart( r.items.map( ( i ) => i.id ), book, true );
				book.textContent = label;
				if ( ok ) toast( '✓ ' + esc( r.tierName ) + ' added for your ' + esc( r.sizeName.toLowerCase() ) + ' · <a href="' + esc( cfg.checkout ) + '">Choose date &amp; time</a>' );
			} );
			// Light up the step the customer is working on.
			form.addEventListener( 'focusin', ( e ) => {
				const fs = e.target.closest( '[data-step]' );
				if ( fs ) steps.forEach( ( li, i ) => li.classList.toggle( 'is-on', i < Number( fs.dataset.step ) ) );
			} );
			update();
		} );
	}

	/* Checkout: carry the place and area chosen in the customizer -------- */
	function prefillCheckout() {
		const where = store.get( 'cv-where' );
		const data = window.wp && window.wp.data;
		if ( ! where || ! data || ! document.querySelector( '.wp-block-woocommerce-checkout' ) ) return;
		let tries = 0;
		const timer = setInterval( () => {
			const checkout = data.dispatch( 'wc/store/checkout' );
			if ( ( checkout && checkout.setAdditionalFields ) || ++tries > 20 ) {
				clearInterval( timer );
				if ( checkout && checkout.setAdditionalFields ) {
					const current = ( data.select( 'wc/store/checkout' ).getAdditionalFields && data.select( 'wc/store/checkout' ).getAdditionalFields() ) || {};
					checkout.setAdditionalFields( { ...current, 'cv/place': current[ 'cv/place' ] || where.placeKey, 'cv/area': current[ 'cv/area' ] || where.areaKey } );
				}
			}
		}, 300 );
	}

	/* Before / after slider ---------------------------------------------- */
	function initBeforeAfter() {
		$$( '[data-cv-ba]' ).forEach( ( fig ) => {
			const range = fig.querySelector( 'input[type=range]' );
			const set = () => fig.style.setProperty( '--pos', range.value + '%' );
			range.addEventListener( 'input', set );
			set();
		} );
	}

	/* Fleet request -------------------------------------------------------- */
	function initFleet() {
		$$( '[data-cv-fleet]' ).forEach( ( form ) => {
			form.addEventListener( 'submit', ( e ) => {
				e.preventDefault();
				if ( ! form.reportValidity() ) return;
				const f = new FormData( form );
				const lines = [
					'Hi Cleanverse, fleet detailing request:',
					'• Company: ' + f.get( 'company' ),
					'• Vehicles: ' + f.get( 'count' ) + ' (' + f.get( 'types' ) + ')',
					'• Service: ' + f.get( 'service' ),
					'• How often: ' + f.get( 'often' ),
					'• Location: ' + f.get( 'area' ),
				];
				if ( String( f.get( 'notes' ) ).trim() ) lines.push( '• Notes: ' + String( f.get( 'notes' ) ).trim() );
				lines.push( 'Contact: ' + f.get( 'name' ) + ', ' + f.get( 'phone' ) );
				window.open( waUrl( lines.join( '\n' ) ), '_blank', 'noopener' );
			} );
		} );
	}

	function init() {
		initOptions();
		initEstimator();
		initBeforeAfter();
		initFleet();
		prefillCheckout();
		// The mini cart and checkout re-render client-side; keep the option buttons in place.
		new MutationObserver( () => initOptions() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
